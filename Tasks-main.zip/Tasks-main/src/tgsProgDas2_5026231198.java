public class tgsProgDas2_5026231198 {

    public static void main(String[] args) {
        String asterix = "*";

        for (int i = 1; i <=4; i++) {
            System.out.println(asterix);
            asterix += "*";
        }
    }
}
